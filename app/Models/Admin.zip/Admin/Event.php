<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use HasFactory;
     public $timestamps = false;
     protected $primaryKey = 'eventId';

     protected $fillable = ['eventName','eventCategory_id','eventOrganizer_id','eventDescription','eventStarttime','eventEndtime','eventStartdate','eventEnddate','eventBanneroneimg','eventType','eventAmount','eventBannertwoimg','eventQrcode','eventStatus','eventLocation','eventCreated_at'];

    //  public $appends = [
    //        'image_url'
           
    // ];


    // public function getImageUrlAttribute(){
    //     return asset('/public/event/'.$this->eventBanneroneimg);
      
    // }

    //   public $appends1 = [
    //        'image_url1'
           
    // ];


    // public function getImageUrl1Attribute(){
    //     return asset('/public/event/'.$this->eventBannertwoimg);
      
    // }
} 
